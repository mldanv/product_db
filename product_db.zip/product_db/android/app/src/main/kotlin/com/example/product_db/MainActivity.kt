package com.example.product_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
